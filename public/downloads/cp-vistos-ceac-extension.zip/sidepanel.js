location.replace("https://ceac.state.gov/GenNIV/Default.aspx");
